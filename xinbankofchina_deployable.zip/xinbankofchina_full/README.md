# Xinbankofchina

Full-stack online banking platform with authentication, admin, and customer support.