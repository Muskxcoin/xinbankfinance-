import { neon } from "@neondatabase/serverless"

// Lazy database connection
let sql: ReturnType<typeof neon> | null = null

function getDb() {
  if (!sql) {
    const connectionString = process.env.DATABASE_URL
    if (!connectionString) {
      throw new Error("DATABASE_URL environment variable is not set")
    }
    sql = neon(connectionString)
  }
  return sql
}

export interface User {
  id: number
  email: string
  password_hash: string
  first_name: string
  last_name: string
  phone?: string
  account_number: string
  balance: number
  created_at: Date
  updated_at: Date
}

export interface Transaction {
  id: number
  from_user_id?: number
  to_user_id?: number
  amount: number
  transaction_type: "transfer" | "deposit" | "withdrawal"
  description?: string
  status: "pending" | "completed" | "failed"
  created_at: Date
}

export async function getUserByEmail(email: string): Promise<User | null> {
  const db = getDb()
  const result = await db`
    SELECT * FROM users WHERE email = ${email} LIMIT 1
  `
  return (result[0] as User) || null
}

export async function getUserById(id: number): Promise<User | null> {
  const db = getDb()
  const result = await db`
    SELECT * FROM users WHERE id = ${id} LIMIT 1
  `
  return (result[0] as User) || null
}

export async function createUser(userData: {
  email: string
  password_hash: string
  first_name: string
  last_name: string
  phone?: string
  account_number: string
}): Promise<User> {
  const db = getDb()
  const result = await db`
    INSERT INTO users (email, password_hash, first_name, last_name, phone, account_number)
    VALUES (${userData.email}, ${userData.password_hash}, ${userData.first_name}, ${userData.last_name}, ${userData.phone || null}, ${userData.account_number})
    RETURNING *
  `
  return result[0] as User
}

export async function getUserTransactions(userId: number, limit = 10): Promise<Transaction[]> {
  const db = getDb()
  const result = await db`
    SELECT t.*, 
           u1.first_name as from_first_name, u1.last_name as from_last_name,
           u2.first_name as to_first_name, u2.last_name as to_last_name
    FROM transactions t
    LEFT JOIN users u1 ON t.from_user_id = u1.id
    LEFT JOIN users u2 ON t.to_user_id = u2.id
    WHERE t.from_user_id = ${userId} OR t.to_user_id = ${userId}
    ORDER BY t.created_at DESC
    LIMIT ${limit}
  `
  return result as Transaction[]
}

export async function createTransaction(transactionData: {
  from_user_id?: number
  to_user_id?: number
  amount: number
  transaction_type: "transfer" | "deposit" | "withdrawal"
  description?: string
}): Promise<Transaction> {
  const db = getDb()
  const result = await db`
    INSERT INTO transactions (from_user_id, to_user_id, amount, transaction_type, description)
    VALUES (${transactionData.from_user_id || null}, ${transactionData.to_user_id || null}, ${transactionData.amount}, ${transactionData.transaction_type}, ${transactionData.description || null})
    RETURNING *
  `
  return result[0] as Transaction
}

export async function updateUserBalance(userId: number, newBalance: number): Promise<void> {
  const db = getDb()
  await db`
    UPDATE users SET balance = ${newBalance}, updated_at = CURRENT_TIMESTAMP
    WHERE id = ${userId}
  `
}

export async function getUserByAccountNumber(accountNumber: string): Promise<User | null> {
  const db = getDb()
  const result = await db`
    SELECT * FROM users WHERE account_number = ${accountNumber} LIMIT 1
  `
  return (result[0] as User) || null
}
