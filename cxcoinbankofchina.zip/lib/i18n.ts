import translations from "./translations.json"

export type Language = "en" | "zh"
export type TranslationKey = string

export function getTranslation(lang: Language, key: string): string {
  const keys = key.split(".")
  let value: any = translations[lang]

  for (const k of keys) {
    value = value?.[k]
  }

  return value || key
}

export function formatCurrency(amount: number, lang: Language = "en"): string {
  if (lang === "zh") {
    return `¥${amount.toLocaleString("zh-CN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
  }
  return `$${amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
}

export function formatDate(date: Date | string, lang: Language = "en"): string {
  const d = new Date(date)
  if (lang === "zh") {
    return d.toLocaleDateString("zh-CN")
  }
  return d.toLocaleDateString("en-US")
}
