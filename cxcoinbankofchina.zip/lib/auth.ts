import bcrypt from "bcryptjs"
import jwt from "jsonwebtoken"
import { getUserByEmail, createUser, type User } from "./db"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10)
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash)
}

export function generateToken(userId: number): string {
  return jwt.sign({ userId }, JWT_SECRET, { expiresIn: "7d" })
}

export function verifyToken(token: string): { userId: number } | null {
  try {
    return jwt.verify(token, JWT_SECRET) as { userId: number }
  } catch {
    return null
  }
}

export async function registerUser(userData: {
  email: string
  password: string
  firstName: string
  lastName: string
  phone?: string
}): Promise<{ user: User; token: string }> {
  const existingUser = await getUserByEmail(userData.email)
  if (existingUser) {
    throw new Error("User already exists")
  }

  const passwordHash = await hashPassword(userData.password)
  const accountNumber = `BOC${Date.now()}${Math.floor(Math.random() * 1000)}`

  const user = await createUser({
    email: userData.email,
    password_hash: passwordHash,
    first_name: userData.firstName,
    last_name: userData.lastName,
    phone: userData.phone,
    account_number: accountNumber,
  })

  const token = generateToken(user.id)
  return { user, token }
}

export async function loginUser(email: string, password: string): Promise<{ user: User; token: string }> {
  const user = await getUserByEmail(email)
  if (!user) {
    throw new Error("Invalid credentials")
  }

  const isValidPassword = await verifyPassword(password, user.password_hash)
  if (!isValidPassword) {
    throw new Error("Invalid credentials")
  }

  const token = generateToken(user.id)
  return { user, token }
}

export function generateAccountNumber(): string {
  return `BOC${Date.now()}${Math.floor(Math.random() * 1000)}`
}
