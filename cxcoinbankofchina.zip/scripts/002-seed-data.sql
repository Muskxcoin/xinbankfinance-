-- Insert sample users
INSERT INTO users (email, password_hash, first_name, last_name, phone, account_number, balance) VALUES
('john.doe@example.com', '$2a$10$rOzJqQjQjQjQjQjQjQjQjOzJqQjQjQjQjQjQjQjQjQjQjQjQjQjQjQ', 'John', 'Doe', '+1234567890', 'BOC001234567890', 15000.00),
('jane.smith@example.com', '$2a$10$rOzJqQjQjQjQjQjQjQjQjOzJqQjQjQjQjQjQjQjQjQjQjQjQjQjQjQ', 'Jane', 'Smith', '+1234567891', 'BOC001234567891', 8500.50),
('wang.lei@example.com', '$2a$10$rOzJqQjQjQjQjQjQjQjQjOzJqQjQjQjQjQjQjQjQjQjQjQjQjQjQjQ', 'Lei', 'Wang', '+8613812345678', 'BOC001234567892', 25000.75)
ON CONFLICT (email) DO NOTHING;

-- Insert sample transactions
INSERT INTO transactions (from_user_id, to_user_id, amount, transaction_type, description, status) VALUES
(1, 2, 500.00, 'transfer', 'Monthly rent payment', 'completed'),
(2, 3, 1200.00, 'transfer', 'Business payment', 'completed'),
(3, 1, 300.00, 'transfer', 'Dinner split', 'completed'),
(1, NULL, 2000.00, 'deposit', 'Salary deposit', 'completed'),
(2, NULL, 1000.00, 'withdrawal', 'ATM withdrawal', 'completed');
