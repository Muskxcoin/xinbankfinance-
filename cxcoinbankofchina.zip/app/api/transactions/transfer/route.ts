import { type NextRequest, NextResponse } from "next/server"
import { verifyToken } from "@/lib/auth"
import { getUserById, getUserByAccountNumber, createTransaction, updateUserBalance } from "@/lib/db"

export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get("auth-token")?.value

    if (!token) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 })
    }

    const payload = verifyToken(token)
    if (!payload) {
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }

    const { recipientAccountNumber, amount, description } = await request.json()

    if (!recipientAccountNumber || !amount || amount <= 0) {
      return NextResponse.json({ error: "Valid recipient account and amount are required" }, { status: 400 })
    }

    const sender = await getUserById(payload.userId)
    if (!sender) {
      return NextResponse.json({ error: "Sender not found" }, { status: 404 })
    }

    if (sender.balance < amount) {
      return NextResponse.json({ error: "Insufficient funds" }, { status: 400 })
    }

    const recipient = await getUserByAccountNumber(recipientAccountNumber)
    if (!recipient) {
      return NextResponse.json({ error: "Recipient account not found" }, { status: 404 })
    }

    if (sender.id === recipient.id) {
      return NextResponse.json({ error: "Cannot transfer to your own account" }, { status: 400 })
    }

    // Create transaction
    const transaction = await createTransaction({
      from_user_id: sender.id,
      to_user_id: recipient.id,
      amount: Number.parseFloat(amount),
      transaction_type: "transfer",
      description,
    })

    // Update balances
    await updateUserBalance(sender.id, sender.balance - Number.parseFloat(amount))
    await updateUserBalance(recipient.id, recipient.balance + Number.parseFloat(amount))

    return NextResponse.json({
      transaction,
      message: "Transfer completed successfully",
    })
  } catch (error) {
    return NextResponse.json({ error: "Transfer failed" }, { status: 500 })
  }
}
