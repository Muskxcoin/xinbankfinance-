import { NextResponse } from "next/server"

export async function GET() {
  try {
    // Check if DATABASE_URL is configured
    if (!process.env.DATABASE_URL) {
      return NextResponse.json(
        {
          status: "error",
          message: "Database not configured",
          database: false,
          timestamp: new Date().toISOString(),
        },
        { status: 500 },
      )
    }

    // Try to import and test database connection
    const { neon } = await import("@neondatabase/serverless")
    const sql = neon(process.env.DATABASE_URL)

    // Simple query to test connection
    await sql`SELECT 1 as test`

    return NextResponse.json({
      status: "healthy",
      message: "All systems operational",
      database: true,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Health check failed:", error)

    return NextResponse.json(
      {
        status: "error",
        message: "Database connection failed",
        database: false,
        error: error instanceof Error ? error.message : "Unknown error",
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
