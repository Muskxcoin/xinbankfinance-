"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/components/auth-provider"
import { useLanguage } from "@/components/language-provider"
import { formatCurrency, formatDate } from "@/lib/i18n"
import { DashboardLayout } from "@/components/dashboard-layout"
import { ArrowUpRight, ArrowDownLeft, CreditCard, Receipt } from "lucide-react"
import Link from "next/link"

interface Transaction {
  id: number
  from_user_id?: number
  to_user_id?: number
  amount: number
  transaction_type: "transfer" | "deposit" | "withdrawal"
  description?: string
  status: "pending" | "completed" | "failed"
  created_at: string
  from_first_name?: string
  from_last_name?: string
  to_first_name?: string
  to_last_name?: string
}

export default function DashboardPage() {
  const { user, refreshUser } = useAuth()
  const { t, language } = useLanguage()
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchTransactions = async () => {
      try {
        const response = await fetch("/api/transactions?limit=5")
        if (response.ok) {
          const data = await response.json()
          setTransactions(data.transactions)
        }
      } catch (error) {
        console.error("Failed to fetch transactions:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchTransactions()
    refreshUser()
  }, [refreshUser])

  if (!user) return null

  const getTransactionIcon = (transaction: Transaction) => {
    if (transaction.from_user_id === user.id) {
      return <ArrowUpRight className="h-4 w-4 text-red-500" />
    } else {
      return <ArrowDownLeft className="h-4 w-4 text-green-500" />
    }
  }

  const getTransactionDescription = (transaction: Transaction) => {
    if (transaction.from_user_id === user.id) {
      return `${t("transactions.sent")} to ${transaction.to_first_name} ${transaction.to_last_name}`
    } else {
      return `${t("transactions.received")} from ${transaction.from_first_name} ${transaction.from_last_name}`
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Welcome Section */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            {t("dashboard.welcomeBack")}, {user.firstName}!
          </h1>
          <p className="text-gray-600 mt-1">{formatDate(new Date(), language)}</p>
        </div>

        {/* Account Overview */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card className="col-span-full md:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5 text-primary" />
                {t("dashboard.accountOverview")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-600">{t("dashboard.availableBalance")}</p>
                  <p className="text-3xl font-bold text-primary">{formatCurrency(user.balance, language)}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">{t("dashboard.accountNumber")}</p>
                  <p className="text-lg font-mono">{user.accountNumber}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{t("dashboard.quickActions")}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Link href="/transfer">
                <Button className="w-full justify-start bg-transparent" variant="outline">
                  <ArrowUpRight className="mr-2 h-4 w-4" />
                  {t("dashboard.sendMoney")}
                </Button>
              </Link>
              <Button className="w-full justify-start bg-transparent" variant="outline">
                <ArrowDownLeft className="mr-2 h-4 w-4" />
                {t("dashboard.requestMoney")}
              </Button>
              <Button className="w-full justify-start bg-transparent" variant="outline">
                <Receipt className="mr-2 h-4 w-4" />
                {t("dashboard.payBills")}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Recent Transactions */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>{t("dashboard.recentTransactions")}</CardTitle>
              <CardDescription>Your latest banking activity</CardDescription>
            </div>
            <Link href="/transactions">
              <Button variant="outline" size="sm">
                {t("dashboard.viewAll")}
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-gray-200 rounded-full animate-pulse" />
                    <div className="flex-1 space-y-2">
                      <div className="h-4 bg-gray-200 rounded animate-pulse" />
                      <div className="h-3 bg-gray-200 rounded w-1/2 animate-pulse" />
                    </div>
                    <div className="h-4 bg-gray-200 rounded w-20 animate-pulse" />
                  </div>
                ))}
              </div>
            ) : transactions.length === 0 ? (
              <div className="text-center py-8 text-gray-500">No transactions yet</div>
            ) : (
              <div className="space-y-4">
                {transactions.map((transaction) => (
                  <div key={transaction.id} className="flex items-center justify-between p-3 rounded-lg border">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                        {getTransactionIcon(transaction)}
                      </div>
                      <div>
                        <p className="font-medium">{getTransactionDescription(transaction)}</p>
                        <p className="text-sm text-gray-600">{formatDate(transaction.created_at, language)}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p
                        className={`font-semibold ${
                          transaction.from_user_id === user.id ? "text-red-600" : "text-green-600"
                        }`}
                      >
                        {transaction.from_user_id === user.id ? "-" : "+"}
                        {formatCurrency(transaction.amount, language)}
                      </p>
                      <p className="text-sm text-gray-500 capitalize">{transaction.status}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
