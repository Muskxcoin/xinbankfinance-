"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useAuth } from "@/components/auth-provider"
import { useLanguage } from "@/components/language-provider"
import { formatCurrency, formatDate } from "@/lib/i18n"
import { DashboardLayout } from "@/components/dashboard-layout"
import { ArrowUpRight, ArrowDownLeft, Search, Filter } from "lucide-react"

interface Transaction {
  id: number
  from_user_id?: number
  to_user_id?: number
  amount: number
  transaction_type: "transfer" | "deposit" | "withdrawal"
  description?: string
  status: "pending" | "completed" | "failed"
  created_at: string
  from_first_name?: string
  from_last_name?: string
  to_first_name?: string
  to_last_name?: string
}

export default function TransactionsPage() {
  const { user } = useAuth()
  const { t, language } = useLanguage()
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    const fetchTransactions = async () => {
      try {
        const response = await fetch("/api/transactions?limit=50")
        if (response.ok) {
          const data = await response.json()
          setTransactions(data.transactions)
        }
      } catch (error) {
        console.error("Failed to fetch transactions:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchTransactions()
  }, [])

  if (!user) return null

  const getTransactionIcon = (transaction: Transaction) => {
    if (transaction.from_user_id === user.id) {
      return <ArrowUpRight className="h-5 w-5 text-red-500" />
    } else {
      return <ArrowDownLeft className="h-5 w-5 text-green-500" />
    }
  }

  const getTransactionDescription = (transaction: Transaction) => {
    if (transaction.transaction_type === "deposit") {
      return t("transactions.deposit")
    } else if (transaction.transaction_type === "withdrawal") {
      return t("transactions.withdrawal")
    } else if (transaction.from_user_id === user.id) {
      return `${t("transactions.sent")} to ${transaction.to_first_name} ${transaction.to_last_name}`
    } else {
      return `${t("transactions.received")} from ${transaction.from_first_name} ${transaction.from_last_name}`
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "text-green-600 bg-green-100"
      case "pending":
        return "text-yellow-600 bg-yellow-100"
      case "failed":
        return "text-red-600 bg-red-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const filteredTransactions = transactions.filter((transaction) => {
    if (!searchTerm) return true

    const searchLower = searchTerm.toLowerCase()
    const description = getTransactionDescription(transaction).toLowerCase()
    const amount = transaction.amount.toString()
    const transactionDescription = transaction.description?.toLowerCase() || ""

    return (
      description.includes(searchLower) || amount.includes(searchLower) || transactionDescription.includes(searchLower)
    )
  })

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">{t("transactions.allTransactions")}</h1>
          <p className="text-gray-600 mt-1">View and search your transaction history</p>
        </div>

        {/* Search and Filter */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search transactions..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button variant="outline" className="sm:w-auto bg-transparent">
                <Filter className="mr-2 h-4 w-4" />
                Filter
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Transactions List */}
        <Card>
          <CardHeader>
            <CardTitle>{t("transactions.allTransactions")}</CardTitle>
            <CardDescription>
              {filteredTransactions.length} transaction{filteredTransactions.length !== 1 ? "s" : ""} found
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="flex items-center space-x-4 p-4 border rounded-lg">
                    <div className="w-12 h-12 bg-gray-200 rounded-full animate-pulse" />
                    <div className="flex-1 space-y-2">
                      <div className="h-4 bg-gray-200 rounded animate-pulse" />
                      <div className="h-3 bg-gray-200 rounded w-1/2 animate-pulse" />
                    </div>
                    <div className="text-right space-y-2">
                      <div className="h-4 bg-gray-200 rounded w-20 animate-pulse" />
                      <div className="h-3 bg-gray-200 rounded w-16 animate-pulse" />
                    </div>
                  </div>
                ))}
              </div>
            ) : filteredTransactions.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                {searchTerm ? "No transactions match your search" : "No transactions found"}
              </div>
            ) : (
              <div className="space-y-4">
                {filteredTransactions.map((transaction) => (
                  <div
                    key={transaction.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center">
                        {getTransactionIcon(transaction)}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{getTransactionDescription(transaction)}</p>
                        {transaction.description && (
                          <p className="text-sm text-gray-600 mt-1">{transaction.description}</p>
                        )}
                        <p className="text-sm text-gray-500 mt-1">
                          {formatDate(transaction.created_at, language)} • ID: {transaction.id}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p
                        className={`text-lg font-semibold ${
                          transaction.from_user_id === user.id ? "text-red-600" : "text-green-600"
                        }`}
                      >
                        {transaction.from_user_id === user.id ? "-" : "+"}
                        {formatCurrency(transaction.amount, language)}
                      </p>
                      <span
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(transaction.status)}`}
                      >
                        {t(`transactions.${transaction.status}`)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
