"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useAuth } from "@/components/auth-provider"
import { useLanguage } from "@/components/language-provider"
import { formatCurrency } from "@/lib/i18n"
import { DashboardLayout } from "@/components/dashboard-layout"
import { ArrowUpRight, Loader2, CheckCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function TransferPage() {
  const { user, refreshUser } = useAuth()
  const { t, language } = useLanguage()
  const [formData, setFormData] = useState({
    recipientAccount: "",
    amount: "",
    description: "",
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }))
    setError("")
    setSuccess(false)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      const response = await fetch("/api/transactions/transfer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          recipientAccountNumber: formData.recipientAccount,
          amount: Number.parseFloat(formData.amount),
          description: formData.description,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Transfer failed")
      }

      setSuccess(true)
      setFormData({ recipientAccount: "", amount: "", description: "" })
      await refreshUser()
    } catch (err) {
      setError(err instanceof Error ? err.message : t("transfer.transferFailed"))
    } finally {
      setLoading(false)
    }
  }

  if (!user) return null

  return (
    <DashboardLayout>
      <div className="max-w-2xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">{t("transfer.sendMoney")}</h1>
          <p className="text-gray-600 mt-1">Transfer funds to another Bank of China account</p>
        </div>

        {/* Current Balance */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">{t("dashboard.availableBalance")}</p>
                <p className="text-2xl font-bold text-primary">{formatCurrency(user.balance, language)}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-600">{t("dashboard.accountNumber")}</p>
                <p className="text-lg font-mono">{user.accountNumber}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Transfer Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ArrowUpRight className="h-5 w-5 text-primary" />
              {t("transfer.transferFunds")}
            </CardTitle>
            <CardDescription>Enter the recipient details and amount to transfer</CardDescription>
          </CardHeader>
          <CardContent>
            {success && (
              <Alert className="mb-6 border-green-200 bg-green-50">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800">{t("transfer.transferSuccess")}</AlertDescription>
              </Alert>
            )}

            {error && (
              <Alert className="mb-6 border-red-200 bg-red-50">
                <AlertDescription className="text-red-800">{error}</AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="recipientAccount">{t("transfer.recipientAccount")}</Label>
                <Input
                  id="recipientAccount"
                  name="recipientAccount"
                  value={formData.recipientAccount}
                  onChange={handleChange}
                  placeholder="BOC001234567890"
                  required
                  className="font-mono"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="amount">{t("transfer.amount")}</Label>
                <Input
                  id="amount"
                  name="amount"
                  type="number"
                  step="0.01"
                  min="0.01"
                  max={user.balance}
                  value={formData.amount}
                  onChange={handleChange}
                  placeholder="0.00"
                  required
                />
                <p className="text-sm text-gray-500">Maximum: {formatCurrency(user.balance, language)}</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">{t("transfer.description")}</Label>
                <Textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  placeholder="Payment for..."
                  rows={3}
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-primary hover:bg-primary/90"
                disabled={loading || !formData.recipientAccount || !formData.amount}
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <ArrowUpRight className="mr-2 h-4 w-4" />
                    {t("transfer.transferFunds")}
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
